package com.example.kabans

object Constants {

    const val commonProb = 0.5
    const val rareProb = 0.3
    const val epicProb = 0.15
    const val legendaryProb = 0.05

}